/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Package, Clock, ShieldCheck, CheckCircle2, AlertCircle, PhoneCall, Play } from 'lucide-react';
import { Order } from '../types';

export default function OrderTracker() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [searched, setSearched] = useState(false);
  const [foundOrders, setFoundOrders] = useState<Order[]>([]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim()) return;

    // Standardize mobile number lookups
    const cleanQuery = phoneNumber.replace(/\s/g, '').trim();

    const rawOrders = localStorage.getItem('iron_power_orders');
    if (rawOrders) {
      const allOrders: Order[] = JSON.parse(rawOrders);
      // Filter out matching phone numbers (suffix or direct match)
      const matches = allOrders.filter(o => 
        o.phoneNumber.includes(cleanQuery) || 
        cleanQuery.includes(o.phoneNumber)
      );
      setFoundOrders(matches);
    } else {
      setFoundOrders([]);
    }
    setSearched(true);
  };

  const getStatusLabelAndStep = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return { label: 'في انتظار تأكيد الموزع هاتفياً', step: 1, desc: 'سيتصل بك أحد موظفينا لتأكيد معلومات التوصيل الخاص بك قريباً جداً.' };
      case 'confirmed':
        return { label: 'تم تأكيد الطلب بنجاح', step: 2, desc: 'تم تجهيز الطرد الخاص بك وهو في طريقه إلى شركة الشحن والتسليم.' };
      case 'shipping':
        return { label: 'قيد الشحن والتوصيل الآن', step: 3, desc: 'الطرد حالياً في سيارة التوزيع وسيتصل بك عامل التوصيل لتحديد ساعة التسليم.' };
      case 'delivered':
        return { label: 'تم تسليم الطرد بنجاح', step: 4, desc: 'نشكرك على اختيارك IRON الأصلي ونأمل أن تكون التجربة فريدة!' };
      default:
        return { label: 'قيد المراجعة', step: 1, desc: '' };
    }
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 md:p-8 backdrop-blur-md" id="tracker-section">
      <div className="flex flex-col gap-4 text-center max-w-xl mx-auto mb-6">
        <span className="text-xs font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-500 uppercase tracking-widest">
          متابعة حالة طلباتي (COD)
        </span>
        <h3 className="text-2xl font-black text-white">تتبع حالة شحن طلبيتك</h3>
        <p className="text-slate-400 text-xs leading-relaxed">
          هل قمت بطلب الشاحن وتريد معرفة متى سيصلك؟ أدخل رقم الهاتف الذي استخدمته في تأكيد الطلب أدناه لمتابعة مسار شحن الطرد لحظة بلحظة.
        </p>
      </div>

      <form onSubmit={handleSearch} className="max-w-md mx-auto flex items-center bg-slate-950 border border-slate-800 focus-within:border-orange-500/80 rounded-2xl p-1.5 transition-all mb-8">
        <input
          type="tel"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          placeholder="رقم الهاتف (الذي اشتريت به)"
          dir="rtl"
          className="bg-transparent flex-1 text-sm text-right text-white focus:outline-none px-4"
        />
        <button
          type="submit"
          className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-orange-700 text-slate-950 px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
        >
          <Search className="w-3.5 h-3.5" />
          <span>ابحث عن طلبي</span>
        </button>
      </form>

      {searched && (
        <div className="max-w-2xl mx-auto">
          {foundOrders.length > 0 ? (
            <div className="flex flex-col gap-6">
              {foundOrders.map((order) => {
                const { label, step, desc } = getStatusLabelAndStep(order.status);
                return (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-slate-950/60 border border-slate-800 rounded-3xl p-5 md:p-6"
                  >
                    {/* Header info */}
                    <div className="flex flex-col sm:flex-row gap-2 justify-between items-start sm:items-center pb-4 border-b border-slate-800/60 mb-6">
                      <div>
                        <span className="text-xs bg-slate-900 border border-slate-800/80 font-mono text-orange-400 px-3 py-1 rounded-full font-bold">
                          طلب رقم: {order.id}
                        </span>
                        <h4 className="text-sm font-bold text-white mt-2">المشتري: {order.fullName}</h4>
                      </div>
                      <div className="text-right sm:text-left">
                        <span className="text-xs text-slate-400 block font-mono">تاريخ الطلب: {new Date(order.createdAt).toLocaleDateString('ar-MA')}</span>
                        <span className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-400 mt-1 block font-mono">
                          المستحق للدفع: {order.totalPrice} درهم
                        </span>
                      </div>
                    </div>

                    {/* Stepper tracker */}
                    <div className="grid grid-cols-4 gap-2 mb-6 text-center relative">
                      {/* Connection bar */}
                      <div className="absolute top-4 left-[12.5%] right-[12.5%] h-0.5 bg-slate-800 -z-10" />
                      <div
                        className="absolute top-4 right-[12.5%] h-0.5 bg-gradient-to-r from-orange-500 to-amber-500 -z-10 transition-all duration-500"
                        style={{ width: `${(step - 1) * 33.3}%` }}
                      />

                      {/* Step 1: Pending */}
                      <div className="flex flex-col items-center gap-1.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          step >= 1 ? 'bg-orange-500 text-slate-950 glow-orange-sm' : 'bg-slate-900 text-slate-500 border border-slate-800'
                        }`}>
                          {step > 1 ? <CheckCircle2 className="w-5 h-5" /> : '1'}
                        </div>
                        <span className={`text-[10px] md:text-xs font-semibold ${step >= 1 ? 'text-orange-400 font-bold' : 'text-slate-500'}`}>تم استلام الطلب</span>
                      </div>

                      {/* Step 2: Confirmed */}
                      <div className="flex flex-col items-center gap-1.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          step >= 2 ? 'bg-orange-500 text-slate-950 glow-orange-sm' : 'bg-slate-900 text-slate-500 border border-slate-800'
                        }`}>
                          {step > 2 ? <CheckCircle2 className="w-5 h-5" /> : '2'}
                        </div>
                        <span className={`text-[10px] md:text-xs font-semibold ${step >= 2 ? 'text-orange-400 font-bold' : 'text-slate-500'}`}>تأكيد الاتصال</span>
                      </div>

                      {/* Step 3: Shipping */}
                      <div className="flex flex-col items-center gap-1.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          step >= 3 ? 'bg-orange-500 text-slate-950 glow-orange-sm' : 'bg-slate-900 text-slate-500 border border-slate-800'
                        }`}>
                          {step > 3 ? <CheckCircle2 className="w-5 h-5" /> : '3'}
                        </div>
                        <span className={`text-[10px] md:text-xs font-semibold ${step >= 3 ? 'text-orange-400 font-bold' : 'text-slate-500'}`}>في التوصيل</span>
                      </div>

                      {/* Step 4: Delivered */}
                      <div className="flex flex-col items-center gap-1.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          step >= 4 ? 'bg-emerald-500 text-slate-950 glow-blue' : 'bg-slate-900 text-slate-500 border border-slate-800'
                        }`}>
                          {step >= 4 ? <CheckCircle2 className="w-5 h-5" /> : '4'}
                        </div>
                        <span className={`text-[10px] md:text-xs font-semibold ${step >= 4 ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>تم الاستلام</span>
                      </div>
                    </div>

                    {/* Context description box */}
                    <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800/60 flex items-start gap-3 text-right">
                      {order.status === 'pending' ? (
                        <Clock className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                      ) : order.status === 'delivered' ? (
                        <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <Package className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <h5 className="text-xs font-bold text-white mb-1">الحالة: {label}</h5>
                        <p className="text-xs text-slate-400 leading-relaxed">{desc}</p>
                      </div>
                    </div>

                    {/* Support Call action */}
                    {order.status === 'pending' && (
                      <div className="mt-4 flex flex-col sm:flex-row gap-3 items-center justify-between p-3.5 bg-orange-500/5 border border-orange-500/10 rounded-xl text-xs">
                        <span className="text-slate-400 text-center sm:text-right">تريد الاستعجال بتسليم شاحنك وطلب تأكيده مباشرة؟ اتصل بمدير التوزيع:</span>
                        <a
                          href="tel:+212600000000"
                          className="flex items-center gap-1.5 font-bold text-orange-400 hover:text-orange-300 font-mono"
                        >
                          <PhoneCall className="w-4 h-4 shrink-0" />
                          <span>+212 600-000000</span>
                        </a>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center bg-slate-950/40 border border-dashed border-slate-800 rounded-3xl p-8 max-w-md mx-auto flex flex-col items-center gap-3"
            >
              <AlertCircle className="w-10 h-10 text-orange-500/80 animate-bounce" />
              <h4 className="text-sm font-bold text-slate-300">عذراً، لم نجد أي طلبات بهذا الرقم!</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                تأكد من إدخال نفس الرقم الذي كتبته في نموذج الطلب (بما في ذلك الصفر الأول، مثل 06XXXXXXXX).
              </p>
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}
