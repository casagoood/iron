/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

const FAQS: FAQItem[] = [
  {
    question: 'هل سعة الـ 50000mAh المعروضة حقيقية؟',
    answer: 'نعم، السعة حقيقية بنسبة 100%. يأتي شاحن IRON IR-516 بخلية ليثيوم كوندنسر مضغوطة بسعة تفوق أربعة أضعاف بطاريات الشواحن التقليدية المتاحة في الأسواق التجارية. يزن الشاحن حوالي 600 جرام بسبب خلايا الطاقة الحقيقية المتواجدة داخله.'
  },
  {
    question: 'ما هي الهواتف والأجهزة المتوافقة مع الكوابل المدمجة؟',
    answer: 'الشاحن متوافق مع كافة الأجهزة على الإطلاق بفضل الكوابل المدمجة الثلاثة عالية الأمان والجودة: كابل Type-C لشحن هواتف الأندرويد الحديثة والآيفون 15/16، كابل Lightning لشحن الآيفون الكلاسيكي والآيباد، وكابل Micro-USB للأجهزة القديمة والسماعات والساعات الذكية.'
  },
  {
    question: 'ما هي مدة التوصيل؟ وهل هناك رسوم شحن إضافية؟',
    answer: 'التوصيل مجاني تماماً بنسبة 100% لمدينة الدار البيضاء (Casablanca) ويستغرق من 12 إلى 24 ساعة كحد أقصى للوصول لباب منزلك. بالنسبة لباقي المدن المغربية، فإن تكلفة الشحن هي 20 درهم مغربي فقط، ويصلك الطرد في غضون 24 إلى 48 ساعة بواسطة موزعينا المعتمدين.'
  },
  {
    question: 'كيف تعمل ميزات الشحن السريع (22.5W) وهل هي آمنة لهاتفي؟',
    answer: 'الشاحن يدعم الشحن السريع الفائق بقوة 22.5 واط مع بروتوكولات PD و QC 3.0. يحتوي الشاحن على شريحة حماية ذكية متطورة تعدل الجهد والتيار تلقائياً بما يتناسب مع مواصفات هاتفك، مما يمنع ارتفاع درجة الحرارة أو الإفراط في شحن البطارية ويحافظ عليها تماماً.'
  },

  {
    question: 'كيف يمكنني الطلب وماهي طريقة الدفع المتوفرة؟',
    answer: 'طريقة الطلب سهلة للغاية، فقط قم بملء الاسم ورقم الهاتف والعنوان في نموذج الطلب المباشر أعلى الصفحة واضغط "تأكيد الشراء". سيتصل بك موظف تأكيد الطلبات الخاص بنا هاتفياً خلال ساعة واحدة لتأكيد موعد الشحن. الدفع يتم نقداً عند الاستلام فقط (Cash on Delivery) بعد فحص المنتج والتأكد من جودته.'
  }
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 md:p-8 backdrop-blur-md" id="faq-section">
      <div className="flex flex-col gap-3 text-center max-w-xl mx-auto mb-8">
        <div className="inline-flex items-center gap-1 bg-orange-500/10 border border-orange-500/20 px-3 py-1 rounded-full w-max mx-auto text-xs text-orange-400 font-bold">
          <HelpCircle className="w-3.5 h-3.5" />
          <span>الأسئلة الشائعة والاستفهامات</span>
        </div>
        <h3 className="text-2xl font-black text-white">نجيب عن جميع مخاوفك واستفساراتك</h3>
        <p className="text-slate-400 text-xs leading-relaxed">
          هل لا تزال متردداً أو تود الاستفسار عن تفاصيل الضمان وطبيعة المنتج الأصلي؟ إليك أجوبة شافية لأهم الأسئلة الشائعة من زبنائنا.
        </p>
      </div>

      <div className="max-w-3xl mx-auto flex flex-col gap-3">
        {FAQS.map((faq, index) => {
          const isOpen = openIndex === index;
          return (
            <div
              key={index}
              className="bg-slate-950/60 border border-slate-800/80 rounded-2xl overflow-hidden transition-all text-right"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="w-full flex justify-between items-center p-5 text-sm md:text-base font-bold text-white hover:bg-slate-900/40 transition-colors cursor-pointer"
              >
                {isOpen ? (
                  <ChevronUp className="w-5 h-5 text-orange-500 shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-500 shrink-0" />
                )}
                <span className="text-right leading-relaxed">{faq.question}</span>
              </button>

              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="px-5 pb-5 pt-1 border-t border-slate-800/30 text-xs md:text-sm text-slate-400 leading-relaxed font-sans arabic-leading-relaxed">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
}
