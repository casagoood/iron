/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, MapPin, Phone, User, Truck, ShieldCheck, CheckCircle, Package } from 'lucide-react';
import { Order } from '../types';

interface CheckoutFormProps {
  onOrderSuccess: (order: Order) => void;
}

const MOROCCAN_CITIES = [
  { name: 'الدار البيضاء (Casablanca)', isCasa: true },
  { name: 'الرباط (Rabat)', isCasa: false },
  { name: 'مراكش (Marrakech)', isCasa: false },
  { name: 'فاس (Fes)', isCasa: false },
  { name: 'طنجة (Tangier)', isCasa: false },
  { name: 'أكادير (Agadir)', isCasa: false },
  { name: 'سلا (Salé)', isCasa: false },
  { name: 'مكناس (Meknes)', isCasa: false },
  { name: 'وجدة (Oujda)', isCasa: false },
  { name: 'القنيطرة (Kenitra)', isCasa: false },
  { name: 'تطوان (Tetouan)', isCasa: false },
  { name: 'تمارة (Temara)', isCasa: false },
  { name: 'آسفي (Safi)', isCasa: false },
  { name: 'المحمدية (Mohammedia)', isCasa: false },
  { name: 'الجديدة (El Jadida)', isCasa: false },
  { name: 'بني ملال (Beni Mellal)', isCasa: false },
  { name: 'الناظور (Nador)', isCasa: false },
  { name: 'مدينة أخرى (Other City)', isCasa: false }
];

export default function CheckoutForm({ onOrderSuccess }: CheckoutFormProps) {
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedCity, setSelectedCity] = useState(MOROCCAN_CITIES[0].name);
  const [address, setAddress] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const isCasa = MOROCCAN_CITIES.find(c => c.name === selectedCity)?.isCasa ?? false;
  const shippingFee = isCasa ? 0 : 20;
  const pricePerItem = 350; // 350 DH
  
  // Special discount strategy: 2 items get 50 DH discount! 3 items get 100 DH discount!
  let discount = 0;
  if (quantity === 2) discount = 50;
  if (quantity >= 3) discount = 120;

  const totalItemPrice = pricePerItem * quantity - discount;
  const grandTotal = totalItemPrice + shippingFee;

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!fullName.trim() || fullName.trim().length < 4) {
      newErrors.fullName = 'الرجاء إدخال الاسم الكامل الثلاثي لتسهيل التسليم';
    }
    // Moroccan phone number regex (06XXXXXXXX or 07XXXXXXXX or with +212)
    const phoneRegex = /^(05|06|07|\+212|00212)[0-9]{8,9}$/;
    if (!phoneNumber.trim()) {
      newErrors.phoneNumber = 'رقم الهاتف مطلوب للاتصال بك قبل التوصيل';
    } else if (!phoneRegex.test(phoneNumber.replace(/\s/g, ''))) {
      newErrors.phoneNumber = 'الرجاء إدخال رقم هاتف مغربي صالح (مثال: 0612345678)';
    }
    if (!address.trim() || address.trim().length < 8) {
      newErrors.address = 'الرجاء إدخال العنوان بالتفصيل (الحي، الشارع، الشقة)';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);

    // Trigger Facebook Pixel Purchase Event immediately on valid order request button click
    try {
      if (typeof window !== 'undefined' && (window as any).fbq) {
        (window as any).fbq('track', 'Purchase', {
          value: grandTotal,
          currency: 'MAD',
          content_name: 'IRON IR-516 Power Bank',
          num_items: quantity
        });
      }
    } catch (err) {
      console.warn('Facebook Pixel Purchase tracking error:', err);
    }

    // Simulate direct network order request (Relying strictly on LocalStorage persistent memory)
    setTimeout(() => {
      const orderId = `IRON-${Math.floor(100000 + Math.random() * 900000)}`;
      const newOrder: Order = {
        id: orderId,
        fullName,
        phoneNumber: phoneNumber.replace(/\s/g, ''),
        city: selectedCity,
        address,
        quantity,
        shippingFee,
        totalPrice: grandTotal,
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      // Retrieve existing orders
      const existingRaw = localStorage.getItem('iron_power_orders');
      const existingOrders: Order[] = existingRaw ? JSON.parse(existingRaw) : [];
      
      // Save order
      localStorage.setItem('iron_power_orders', JSON.stringify([newOrder, ...existingOrders]));
      
      setIsSubmitting(false);
      onOrderSuccess(newOrder);

      // Construct WhatsApp confirmation message
      const whatsappMessage = `السلام عليكم، أريد تأكيد طلب شاحن IRON 50000mAh:\nالاسم: ${fullName}\nالهاتف: ${phoneNumber}\nالمدينة: ${selectedCity}`;
      const whatsappUrl = `https://wa.me/212704864461?text=${encodeURIComponent(whatsappMessage)}`;
      
      // Redirect the user automatically to WhatsApp
      window.location.href = whatsappUrl;

      // Clean inputs
      setFullName('');
      setPhoneNumber('');
      setAddress('');
      setNotes('');
      setQuantity(1);
    }, 1200);
  };

  return (
    <div className="bg-slate-900 border-2 border-orange-500/30 rounded-3xl p-6 md:p-8 relative overflow-hidden" id="order-form">
      {/* Visual background badge */}
      <div className="absolute top-0 left-0 bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 text-xs font-bold px-4 py-2 rounded-br-2xl uppercase tracking-wider flex items-center gap-1.5 shadow-md">
        <Truck className="w-3.5 h-3.5 animate-bounce" />
        <span>الدفع عند الاستلام (COD)</span>
      </div>

      <div className="mt-4 mb-6">
        <h3 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <ShoppingBag className="w-6 h-6 text-orange-500" />
          نموذج الطلب السريع
        </h3>
        <p className="text-slate-400 text-xs mt-1.5 leading-relaxed">
          املأ الاستمارة الآن وسيصلك المنتج إلى باب منزلك مع الدفع عند الاستلام. ضمان أصالة وجودة 100%!
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-5 text-right">
        {/* Full Name */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-orange-400" />
            الاسم الكامل:
          </label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            dir="rtl"
            placeholder="مثال: محمد العلوي"
            className={`bg-slate-950 border rounded-xl p-3 text-sm text-white focus:outline-none focus:border-orange-500 transition-all ${
              errors.fullName ? 'border-red-500/70 bg-red-500/5' : 'border-slate-800'
            }`}
          />
          {errors.fullName && <span className="text-red-400 text-[11px] font-medium">{errors.fullName}</span>}
        </div>

        {/* Phone number */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
            <Phone className="w-3.5 h-3.5 text-orange-400" />
            رقم الهاتف (الواتساب مفضل للتأكيد):
          </label>
          <input
            type="tel"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            dir="ltr"
            placeholder="0612345678"
            className={`bg-slate-950 border rounded-xl p-3 text-sm text-left text-white focus:outline-none focus:border-orange-500 transition-all ${
              errors.phoneNumber ? 'border-red-500/70 bg-red-500/5' : 'border-slate-800'
            }`}
          />
          {errors.phoneNumber && <span className="text-red-400 text-[11px] font-medium">{errors.phoneNumber}</span>}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* City Selector */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-orange-400" />
              المدينة:
            </label>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-orange-500 transition-all cursor-pointer"
            >
              {MOROCCAN_CITIES.map((city) => (
                <option key={city.name} value={city.name} className="bg-slate-900">
                  {city.name}
                </option>
              ))}
            </select>
          </div>

          {/* Quantity Selector */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
              <Package className="w-3.5 h-3.5 text-orange-400" />
              الكمية المطلوبة:
            </label>
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl h-[46px] overflow-hidden">
              <button
                type="button"
                onClick={() => setQuantity(q => q + 1)}
                className="w-12 h-full bg-slate-900 hover:bg-slate-800 text-white font-bold transition-all text-lg flex items-center justify-center cursor-pointer"
              >
                +
              </button>
              <span className="flex-1 text-center text-sm font-bold text-white font-mono">{quantity}</span>
              <button
                type="button"
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-12 h-full bg-slate-900 hover:bg-slate-800 text-white font-bold transition-all text-lg flex items-center justify-center cursor-pointer"
              >
                -
              </button>
            </div>
          </div>
        </div>

        {/* Interactive Discounts Banner */}
        {quantity > 1 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-2.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-bold text-center flex items-center justify-center gap-1"
          >
            <span className="animate-pulse">🎁</span>
            <span>تهانينا! حصلت على عرض خاص وخصم بقيمة {discount} درهم لتطلبك أكثر من قطعة!</span>
          </motion.div>
        )}

        {/* Address */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-orange-400" />
            العنوان السكني الكامل بالتفصيل:
          </label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            dir="rtl"
            placeholder="اسم الحي، الشارع، ورقم الباب أو الشقة..."
            rows={2}
            className={`bg-slate-950 border rounded-xl p-3 text-sm text-white focus:outline-none focus:border-orange-500 transition-all ${
              errors.address ? 'border-red-500/70 bg-red-500/5' : 'border-slate-800'
            }`}
          />
          {errors.address && <span className="text-red-400 text-[11px] font-medium">{errors.address}</span>}
        </div>

        {/* Additional notes */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-400">أي ملاحظات إضافية (أوقات التوصيل المفضلة، إلخ):</label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            dir="rtl"
            placeholder="اختياري..."
            className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-orange-500 transition-all"
          />
        </div>

        {/* Pricing break downs cards */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 flex flex-col gap-2.5">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>سعر المنتج الأساسي:</span>
            <span className="font-mono text-white font-medium">{pricePerItem} درهم</span>
          </div>
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>الكمية:</span>
            <span className="font-mono text-white font-medium">{quantity} حبات</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between items-center text-xs text-emerald-400">
              <span>خصم الكمية التلقائي:</span>
              <span className="font-mono font-bold">-{discount} درهم</span>
            </div>
          )}
          <div className="flex justify-between items-center text-xs text-slate-400 border-b border-slate-800/80 pb-2.5">
            <span>تكلفة الشحن والتوصيل:</span>
            <span className="font-medium text-white flex items-center gap-1 font-mono">
              {shippingFee === 0 ? (
                <span className="text-emerald-400 font-bold">مـجـانـي (0 درهم)</span>
              ) : (
                `+ ${shippingFee} درهم`
              )}
            </span>
          </div>
          <div className="flex justify-between items-center pt-1">
            <span className="text-sm font-bold text-white">المبلغ الإجمالي المستحق:</span>
            <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-500 font-mono">
              {grandTotal} درهم
            </span>
          </div>
        </div>

        {/* Action button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full relative py-4 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 hover:scale-[1.01] text-slate-950 font-black text-base rounded-2xl transition-all shadow-xl shadow-orange-500/10 cursor-pointer overflow-hidden flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <div className="flex items-center gap-2">
              <svg className="animate-spin h-5 w-5 text-slate-950" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              <span>جاري تسجيل طلبك الآن...</span>
            </div>
          ) : (
            <>
              <CheckCircle className="w-5 h-5 shrink-0" />
              <span>تأكيد الشراء الآن (الدفع عند الاستلام)</span>
            </>
          )}
        </button>

        {/* Guarantees list */}
        <div className="flex justify-center items-center gap-4 mt-1 border-t border-slate-800/60 pt-4">
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-orange-500 shrink-0" />
            <span>منتج أصلي 100%</span>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
            <Truck className="w-4 h-4 text-orange-500 shrink-0" />
            <span>توصيل سريع وبأمان</span>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
            <Package className="w-4 h-4 text-orange-500 shrink-0" />
            <span>فحص المنتج عند الاستلام</span>
          </div>
        </div>
      </form>
    </div>
  );
}
