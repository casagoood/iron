/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, MessageSquarePlus, Check, ThumbsUp, Sparkles, Smile } from 'lucide-react';
import { Review } from '../types';

const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    name: 'سفيان كريم',
    city: 'الدار البيضاء',
    rating: 5,
    comment: 'الباور بانك وحش حقيقي بكل معنى الكلمة! شريتو لرحلات التخييم في النواحي، وشحن ليا تليفوني وتليفون الزوجة ديالي كتر من 8 المرات وبقا فيه 25% الشحن السريع ديال 22.5 واط خدام كأنه خيط الضو د الدار. أنصح به بشدة جودة أصلية ممتازة.',
    date: '2026-05-18',
    verified: true,
    likes: 24,
  },
  {
    id: 'rev-2',
    name: 'فاطمة الزهراء بنجلون',
    city: 'الرباط',
    rating: 5,
    comment: 'الصراحة زوين بزاف، عجبني الحبل اللي لاصق فيه حيت ديما كنسى الكوابل ديالي ف الدار. دابا كلشي مدمج معاه. وشاحن كبيير كيدوم ليا سيمانة كاملة بلا ما نحتاج ندوزو لبرييز الكهرباء. عاد التوصيل ف الرباط وصلني ف 24 ساعة فقط.',
    date: '2026-05-12',
    verified: true,
    likes: 18,
  },
  {
    id: 'rev-3',
    name: 'أمين الخياط',
    city: 'مراكش',
    rating: 4,
    comment: 'الجودة تبارك الله لا يعلى عليها. الشاحن ثقيل شوية فاليد حيت السعة ديالو 50000 حقيقية ماشي بحال الشواحن الكاذبة لي فالأسواق. الشاشة الرقمية مريحة جداً كتعطيك النسبة المئوية بالضبط. شكراً للموزع على المعاملة الطيبة.',
    date: '2026-05-09',
    verified: true,
    likes: 12,
  },
  {
    id: 'rev-4',
    name: 'عثمان تجموعتي',
    city: 'طنجة',
    rating: 5,
    comment: 'منتج ممتاز كازا توصيل كان بالمجان والتوصيل سريع. خدمت به فالبحر والخدمة كنشحن بيه حتى لابتوب ماك بوك ديالي بكفاءة هائلة لأنه كيدعم البروتوكولات الجديدة. خيط تايب سي مدمج فيه صحيح وقوي.',
    date: '2026-04-28',
    verified: true,
    likes: 31,
  }
];

export default function ReviewsSection() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('iron_power_reviews');
    if (saved) {
      setReviews(JSON.parse(saved));
    } else {
      setReviews(INITIAL_REVIEWS);
      localStorage.setItem('iron_power_reviews', JSON.stringify(INITIAL_REVIEWS));
    }
  }, []);

  const handleLike = (id: string) => {
    const updated = reviews.map(r => {
      if (r.id === id) {
        return { ...r, likes: r.likes + 1 };
      }
      return r;
    });
    setReviews(updated);
    localStorage.setItem('iron_power_reviews', JSON.stringify(updated));
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim() || !city.trim()) return;

    const newRev: Review = {
      id: `rev-${Math.random().toString(36).substring(2, 9)}`,
      name,
      city,
      rating,
      comment,
      date: new Date().toISOString().split('T')[0],
      verified: true,
      likes: 0
    };

    const updated = [newRev, ...reviews];
    setReviews(updated);
    localStorage.setItem('iron_power_reviews', JSON.stringify(updated));

    // Clear inputs and give confirmation
    setName('');
    setCity('');
    setComment('');
    setRating(5);
    setSuccessMsg('تمت إضافة تقييمك بنجاح! شكراً جزيلاً لمشاركتنا تجربتك الجريئة.');
    setTimeout(() => {
      setSuccessMsg('');
      setShowAddForm(false);
    }, 2500);
  };

  return (
    <div className="bg-slate-950/40 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden" id="reviews-section">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-slate-800/60 mb-8">
        <div>
          <span className="text-xs font-bold text-orange-400 uppercase tracking-wider block mb-1">تجارب المشترين وبكل مصداقية</span>
          <h3 className="text-2xl font-black text-white flex items-center gap-2">
            آراء وتقييمات زبنائنا الكرام
            <Sparkles className="w-5 h-5 text-amber-400 animate-spin" />
          </h3>
          <p className="text-xs text-slate-400 mt-1">المصداقية هي أساس تعاملنا، طالع آراء زبنائنا الأصليين بالمغرب.</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="p-3 bg-slate-900 hover:bg-slate-800 text-orange-400 hover:text-orange-300 font-bold text-xs rounded-xl border border-slate-800 flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
        >
          <MessageSquarePlus className="w-4 h-4" />
          <span>إضافة تقييمك للمنتج</span>
        </button>
      </div>

      {/* Write a review Form wrapper */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-8"
          >
            <form onSubmit={handleSubmitReview} className="bg-slate-900/60 border border-slate-800/85 p-5 md:p-6 rounded-2xl flex flex-col gap-4 text-right">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Smile className="w-4 h-4 text-orange-400" />
                اكتب مراجعتك بكل أمانة وثقة:
              </h4>

              {successMsg ? (
                <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold rounded-xl text-center">
                  {successMsg}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs text-slate-300">اسمك الشخصي أو العائلي:</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="مثال: يونس الوردي"
                        className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-orange-500 transition-all"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs text-slate-300">المدينة:</label>
                      <input
                        type="text"
                        required
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="مثال: فاس"
                        className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-orange-500 transition-all"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-slate-300">التقييم بالنجوم:</label>
                    <div className="flex items-center gap-1.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star className={`w-6 h-6 ${star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'}`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-slate-300">شاركنا تجربتك المفصلة مع الشاحن:</label>
                    <textarea
                      required
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="كيف كانت تجربتك؟ كم يدوم الشاحن معك؟ رأيك في الكوابل المدمجة وسرعة التوصيل..."
                      rows={3}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-orange-500 transition-all"
                    />
                  </div>

                  <button
                    type="submit"
                    className="self-end px-5 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-orange-700 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                  >
                    نشر المراجعة والمصادقة
                  </button>
                </>
              )}
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid of customer testimonies */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {reviews.map((rev) => (
          <motion.div
            key={rev.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-900/40 border border-slate-850 p-5 md:p-6 rounded-2xl flex flex-col justify-between hover:border-slate-800 transition-all text-right"
          >
            <div>
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-4 h-4 ${s <= rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'}`}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  <span className="text-[10px] text-emerald-400 font-bold font-sans">مشتري مؤكد للعلبة الأصلية</span>
                  <Check className="w-3 h-3 text-emerald-400" />
                </div>
              </div>

              <h4 className="text-sm font-bold text-white">
                {rev.name} 
                <span className="text-slate-400 font-normal mr-2">({rev.city})</span>
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mt-2.5 font-sans arabic-leading-relaxed">
                {rev.comment}
              </p>
            </div>

            <div className="flex justify-between items-center mt-5 pt-3 border-t border-slate-800/50 text-[10px] text-slate-500">
              <span className="font-mono">{rev.date}</span>
              <button
                onClick={() => handleLike(rev.id)}
                className="flex items-center gap-1 bg-slate-950 hover:bg-slate-800 px-3 py-1 rounded-lg border border-slate-800/60 hover:text-white transition-colors cursor-pointer"
              >
                <ThumbsUp className="w-3 h-3 text-orange-400" />
                <span>أعجبني تقييمه ({rev.likes})</span>
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
