/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Zap, Cable, ShieldCheck, Award } from 'lucide-react';

export default function PowerBankSimulator() {
  return (
    <div className="bg-slate-950/80 border border-slate-800/80 rounded-3xl p-6 md:p-8 relative flex flex-col gap-6" id="simulator-widget">
      {/* Background radial highlight */}
      <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/5 to-transparent rounded-3xl pointer-events-none" />

      {/* Header with Certified Original Product details */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/50">
        <div className="text-right w-full">
          <h4 className="text-base sm:text-lg font-bold text-white flex items-center gap-2 justify-start">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500 shrink-0" />
            شاحن IRON IR-516 بقوة 50K mAh
          </h4>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-1">العلبة المغربية الأصلية الفاخرة - ضمان أصالة كامل ومستورد لمعايير الجودة الأوروبية</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center py-2">
        {/* The Real Product Photo Section */}
        <div className="lg:col-span-12 xl:col-span-7 relative rounded-2xl overflow-hidden border border-slate-800/80 bg-[#07080b] group shadow-2xl w-full flex items-center justify-center">
          <img
            src="../assets/images/power_bank_lifestyle_1779481287788.png"
            alt="استخدام رائع ومتعدد لأجهزة متعددة مع باوربانك IRON"
            referrerPolicy="no-referrer"
            className="w-full h-auto object-contain rounded-2xl transition-all duration-700 group-hover:scale-[1.01]"
          />
          <div className="absolute top-3 right-3 bg-slate-950/85 md:bg-slate-950/80 border border-orange-500/30 backdrop-blur-sm text-[10px] font-bold text-orange-400 px-2.5 py-1 rounded-lg">
            ⚡ شحن أجهزة متعددة بذكاء وسرعة فائقة
          </div>
        </div>

        {/* Premium Specifications Panel */}
        <div className="lg:col-span-12 xl:col-span-5 text-right flex flex-col gap-4">
          <div>
            <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest bg-orange-500/15 border border-orange-500/30 px-2.5 py-1 rounded-full">
              المواصفات الفنية المعتمدة
            </span>
            <h4 className="text-lg font-extrabold text-white mt-3 font-mono">IRON IR-516 | 50,000mAh Power Bank</h4>
            <p className="text-xs text-slate-300 leading-relaxed font-sans mt-1">
              يأتي هذا الشاحن بنظام حماية ذكي يضمن شحن أجهزتك بأمان كامل مع تقليل الحرارة إلى أدنى مستوياتها.
            </p>
          </div>

          <div className="flex flex-col gap-2.5">
            <div className="flex items-start gap-2.5 bg-slate-900/40 border border-slate-900 p-3 rounded-2xl">
              <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500 shrink-0">
                <Award className="w-4 h-4" />
              </div>
              <div className="text-right">
                <h5 className="text-xs font-bold text-white">سعة 50,000 mAH حقيقية وضخمة</h5>
                <p className="text-[11px] text-slate-400 mt-0.5 font-sans">تسمح بشحن هاتف آيفون أو جالاكسي بالكامل من 10 إلى 12 مرات متتالية.</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 bg-slate-900/40 border border-slate-900 p-3 rounded-2xl">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 shrink-0">
                <Zap className="w-4 h-4" />
              </div>
              <div className="text-right">
                <h5 className="text-xs font-bold text-white">قوة شحن فائق 22.5W سوبر سريع</h5>
                <p className="text-[11px] text-slate-400 mt-0.5 font-sans">يشحن بطارية هاتفك إلى 60% في نصف ساعة فقط بفضل شرائح السيليكون المتطورة.</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 bg-slate-900/40 border border-slate-900 p-3 rounded-2xl">
              <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 shrink-0">
                <Cable className="w-4 h-4" />
              </div>
              <div className="text-right">
                <h5 className="text-xs font-bold text-white">3 كابلات مدمجة مغلفة بنسيج نانو</h5>
                <p className="text-[11px] text-slate-400 mt-0.5 font-sans">يحتوي في خلفه على كابل Type-C و Lightning (آبل) وكابل Micro مركبين دون حاجة لأسلاك زائدة.</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 bg-slate-900/40 border border-slate-900 p-3 rounded-2xl">
              <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="text-right">
                <h5 className="text-xs font-bold text-white">نظام حماية من الجهد ودرجات الحرارة</h5>
                <p className="text-[11px] text-slate-400 mt-0.5 font-sans">أمان أوروبي معزز يقي البطاريات من فرط الشحن، التماس الكهربائي، والتسخين الزائد أثناء السفر.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
