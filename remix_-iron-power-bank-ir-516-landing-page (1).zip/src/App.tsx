/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  Battery, 
  ShieldAlert, 
  Award, 
  Truck, 
  Sparkles, 
  Check, 
  Volume2, 
  Clock, 
  Menu, 
  X, 
  Phone, 
  Heart, 
  Instagram, 
  Facebook, 
  FileCheck2,
  AlertCircle
} from 'lucide-react';
import PowerBankSimulator from './components/PowerBankSimulator';
import CheckoutForm from './components/CheckoutForm';
import FAQSection from './components/FAQSection';
import { Order } from './types';

function IronLogo({ className = "h-12 w-auto" }: { className?: string }) {
  return (
    <svg viewBox="0 0 280 80" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Hexagon Shield Icon group */}
      <g transform="translate(5, 0) scale(0.8)" fill="#ff6000">
        {/* Left & Right Bracket outer hexagon with open top */}
        <path 
          d="M 32,28 L 15,38 L 15,75 L 50,95 L 85,75 L 85,38 L 68,28" 
          fill="none" 
          stroke="#ff6000" 
          strokeWidth="11" 
          strokeLinejoin="miter" 
          strokeLinecap="butt"
        />
        {/* The 'i' hexagon dot */}
        <polygon points="50,11 59,16 59,25 50,30 41,25 41,16" />
        {/* The 'i' stem */}
        <polygon points="41,38 59,38 59,69 50,75 41,69" />
      </g>

      {/* Logotype "IRON" */}
      <path fill="#ff6000" d="M 95,16 H 106 V 56 H 95 Z" />
      
      <g fill="#ff6000">
        <path fillRule="evenodd" d="M 114,16 H 146 c 4,0 8,3 8,8 v 6 c 0,5 -4,8 -8,8 H 125 v 18 h -11 V 16 Z M 125,24 v 8 h 18 v -8 H 125 Z" />
        <polygon points="127,38 139,38 154,56 141,56" />
      </g>
      
      <path fill="#ff6000" fillRule="evenodd" d="M 172,16 H 202 c 5,0 10,4 10,9 V 47 c 0,5 -5,9 -10,9 H 172 c -5,0 -10,-4 -10,-9 V 25 c 0,-5 5,-9 10,-9 Z M 173,27 v 18 c 0,2 2,4 4,4 h 20 c 2,0 4,-2 4,-4 V 27 c 0,-2 -2,-4 -4,-4 H 177 c -2,0 -4,2 -4,4 Z" />
      
      <path fill="#ff6000" d="M 220,16 h 11 l 23,32 V 16 h 11 v 40 h -11 l -23,-32 v 32 h -11 Z" />

      {/* Subtitle "INSURANCE QUALITY" */}
      <text 
        x="95" 
        y="71" 
        fill="#ffffff" 
        fontFamily="'Inter', 'Space Grotesk', sans-serif" 
        fontSize="10" 
        fontWeight="800" 
        letterSpacing="1.2"
        textLength="170" 
        lengthAdjust="spacing"
      >
        INSURANCE QUALITY
      </text>
    </svg>
  );
}

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  
  // High-conversion Countdown Timer
  const [timeLeft, setTimeLeft] = useState({ hours: 2, minutes: 44, seconds: 51 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          // Reset
          return { hours: 3, minutes: 0, seconds: 0 };
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleOrderSuccess = (order: Order) => {
    setPlacedOrder(order);
    setShowSuccessModal(true);
    // Smooth scroll to the top of the modal or keep it centered
  };

  const handleCloseModal = () => {
    setShowSuccessModal(false);
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#07080b] font-sans antialiased selection:bg-orange-500 selection:text-slate-950 text-slate-100" dir="rtl">
      
      {/* 1. Announcement Bar */}
      <div className="bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 text-slate-950 text-[11px] sm:text-xs font-black py-2 px-4 text-center select-none flex items-center justify-center gap-2 border-b border-orange-500/20 sticky top-0 z-50 shadow-md">
        <Truck className="w-4 h-4 animate-bounce shrink-0" />
        <span className="tracking-wide">
          توصيل مـجـانـي بمدينة الدار البيضاء (Casablanca) و 20 درهم فقط لباقي مدن المغرب 📦 الدفع عند الاستلام بعد فحص الجودة!
        </span>
      </div>

      {/* 2. Global Sleek Header */}
      <header className="bg-[#0b0c11]/90 border-b border-slate-900 sticky top-8 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex justify-between items-center">
          
          {/* Logo Brand Shield */}
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => scrollToSection('hero')}>
            <IronLogo className="h-11 w-auto" />
          </div>

          {/* Desktop Nav Actions */}
          <nav className="hidden md:flex items-center gap-6 font-semibold text-sm text-slate-300">
            <button onClick={() => scrollToSection('simulator-widget')} className="hover:text-orange-400 transition-colors cursor-pointer">مواصفات الشاحن الأصلي</button>
          </nav>



          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile slide down menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-b border-slate-900 bg-[#0b0c11] px-4 py-5 flex flex-col gap-4 font-semibold text-sm text-slate-300 border-t border-slate-900/50"
            >
              <button onClick={() => scrollToSection('simulator-widget')} className="py-2 hover:text-orange-400 text-right transition-colors cursor-pointer">📸 صورة الشاحن ومواصفاته</button>
              
              <button
                onClick={() => scrollToSection('order-form')}
                className="w-full text-center py-3 bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black text-sm rounded-xl"
              >
                اطلب الآن هاتفياً أو عبر النموذج
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* 3. Hero Section Area */}
      <section className="relative pt-12 pb-20 md:py-24 overflow-hidden mt-2" id="hero">
        {/* Subtle decorative grid and lighting patterns */}
        <div className="absolute top-0 right-0 w-full h-[500px] bg-gradient-to-b from-orange-500/10 via-amber-500/5 to-transparent pointer-events-none" />
        <div className="absolute top-20 left-10 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute top-80 right-20 w-[400px] h-[400px] bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          


          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Right text layout */}
            <div className="lg:col-span-6 flex flex-col justify-center text-right">
              
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-orange-500/30 px-3.5 py-1.5 rounded-full w-max text-xs text-orange-400 font-bold mb-6">
                <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
                <span>طاقة موثوقة ومستمرة لجميع أجهزتك الذكية</span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-5xl font-extrabold text-white leading-tight mb-5 tracking-tight">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-400">لا تدع بطارية هاتفك</span><br />
                توقف يومك أو تعيق مهامك!
              </h1>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-sans mb-8 max-w-xl md:arabic-leading-relaxed">
                شاحن <strong>IRON IR-516</strong> الأصلي بقوة <strong>50,000 مللي أمبير</strong> وشحن خارق بسرعة <strong>22.5 واط</strong>. يأتيكم بثلاث كوابل مدمجة فائقة المتانة ليكون رفيقك المثالي في العمل، الطبيعة، والتنقل الطويل.
              </p>

              {/* Countdown Timer Promo display with stock limits */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 mb-8 max-w-xl">
                <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                  <div className="text-center sm:text-right">
                    <span className="text-xs text-slate-400 font-bold">عرض الجمعة المحدود خصم 30%</span>
                    <div className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-emerald-500 font-mono mt-1 flex items-baseline gap-1 justify-center sm:justify-start">
                      <span>350 درهم</span>
                      <span className="text-xs text-slate-500 line-through font-normal">450 درهم</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5 font-mono text-center">
                      <div className="bg-slate-950 px-3 py-2 rounded-xl text-orange-400 border border-slate-800 font-extrabold text-sm min-w-[40px]">
                        {timeLeft.hours.toString().padStart(2, '0')}
                        <span className="text-[7px] text-slate-500 block font-sans mt-0.5">ساعة</span>
                      </div>
                      <span className="text-white font-bold text-center self-center">:</span>
                      <div className="bg-slate-950 px-3 py-2 rounded-xl text-orange-400 border border-slate-800 font-extrabold text-sm min-w-[40px]">
                        {timeLeft.minutes.toString().padStart(2, '0')}
                        <span className="text-[7px] text-slate-500 block font-sans mt-0.5">دقيقة</span>
                      </div>
                      <span className="text-white font-bold text-center self-center">:</span>
                      <div className="bg-slate-950 px-3 py-2 rounded-xl text-orange-400 border border-slate-800 font-extrabold text-sm min-w-[40px]">
                        {timeLeft.seconds.toString().padStart(2, '0')}
                        <span className="text-[7px] text-slate-500 block font-sans mt-0.5">ثانية</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="w-full h-1 bg-slate-950 rounded-full overflow-hidden mt-4 relative">
                  <div className="h-full bg-gradient-to-r from-orange-500 to-amber-400 animate-pulse rounded-full" style={{ width: '28%' }} />
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 mt-2 font-semibold">
                  <span>بقي 9 قطع فقط في المخزون المغربي</span>
                  <span className="text-orange-400 animate-pulse">● الطلب مرتفع جداً حالياً</span>
                </div>
              </div>

              {/* Fast action pointers */}
              <div className="flex flex-col sm:flex-row gap-4 items-center mb-8 max-w-xl">
                <button
                  onClick={() => scrollToSection('order-form')}
                  className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 hover:scale-[1.01] text-slate-950 font-black text-base rounded-2xl transition-all shadow-lg shadow-orange-500/10 cursor-pointer flex items-center justify-center gap-2"
                >
                  <CartIcon className="w-5 h-5 shrink-0" />
                  <span>اطلب العلبة الأصلية الآن</span>
                </button>
              </div>

              {/* Features summary bullets */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 border-t border-slate-900/50 pt-6">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs text-slate-300 font-semibold">توصيل مجاني بكازا</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs text-slate-300 font-semibold">ضمان 3 أشهر حقيقي</span>
                </div>
                <div className="flex items-center gap-2 col-span-2 md:col-span-1">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs text-slate-300 font-semibold">فحص العلبة قبل الدفع</span>
                </div>
              </div>

            </div>

            {/* Left Simulator interactive engine */}
            <div className="lg:col-span-6 flex flex-col justify-center">
              <PowerBankSimulator />
            </div>

          </div>

        </div>
      </section>



      {/* 5.5. Real Product Image & Packaging Box Showcase */}
      <section className="py-16 md:py-20 relative bg-slate-950/20" id="real-product-showcase">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          
          <div className="flex flex-col gap-4 max-w-2xl mx-auto mb-10 text-center">
            <span className="text-xs font-bold text-orange-400 uppercase tracking-widest bg-orange-500/10 border border-orange-500/20 px-3 py-1 rounded-full w-max mx-auto">
              📷 العلبة الأصلية الفاخرة والمنتج الواقعي
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">صورة واقعية ودقيقة لباوربانك IRON والعلبتين المرافقتين</h2>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
              هذه هي علبة الشاحن والباور بانك الحقيقي ذو السعة المضمونة 50,000 مللي أمبير. صورة حقيقية تماماً دون أي تعديل لتكون على دراية تامة بالمنتج والعلبتين الفاخرتين قبل أن يصل إليك مندوب التوصيل.
            </p>
          </div>

          {/* Real product photo - power_bank_pro.png - shown completely and beautifully */}
          <div className="max-w-4xl mx-auto rounded-3xl overflow-hidden border border-slate-900/80 bg-[#0b0c11]/40 p-1.5 md:p-3 shadow-2xl transition-all duration-700 hover:border-orange-500/20">
            <img 
              src="./assets/images/power_bank_pro.png" 
              alt="صورة واقعية شاحن وعلبة IRON الأصلي" 
              referrerPolicy="no-referrer"
              className="w-full h-auto rounded-2xl object-contain max-h-[75vh]"
            />
          </div>

        </div>
      </section>

      {/* 6. Realistic Lifestyle Showcase (At Work, Nature, commuting) */}
      <section className="py-20 bg-[#090a0e]/60 relative border-y border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col gap-4 text-center max-w-xl mx-auto mb-16">
            <span className="text-xs font-bold text-orange-400 uppercase tracking-widest bg-orange-500/10 border border-orange-500/20 px-3 py-1 rounded-full w-max mx-auto">
              حلول طاقة موثوقة يومياً
            </span>
            <h2 className="text-3xl font-extrabold text-white">رفيقك العملي في مختلف الظروف</h2>
            <p className="text-slate-400 text-xs sm:text-sm">
              صُمم شاحن IRON ليوفر لأجهزتك طاقة آمنة ومستمرة خلال فترات العمل الطويلة، السفر والتنقل، أو أثناء أنشطتك الترفيهية الخارجية بكل سهولة.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* At work */}
            <div className="bg-slate-950/60 border border-slate-850 hover:border-orange-500/20 rounded-3xl p-5 relative overflow-hidden flex flex-col justify-between group transition-all text-right">
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-orange-500/5 to-transparent rounded-bl-full pointer-events-none" />
              <div>
                <div className="h-44 w-full rounded-2xl overflow-hidden mb-5 border border-slate-900">
                  <img 
                    src="./assets/images/power_bank_lifestyle_1779481287788.png" 
                    alt="استخدام الباوربانك في بيئة العمل والمكتب" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-white">في العمل (At Work)</h3>
                  <div className="w-8 h-8 border border-slate-800 rounded-lg flex items-center justify-center text-orange-400 font-bold font-sans text-xs">01</div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed font-sans arabic-leading-relaxed">
                  أنقذ مهام عملك واجتماعاتك الهامة من الضياع والتوقف. لا تنتظر مقابس الكهرباء ولا تخف من تعطل بريدك الإلكتروني والملفات الحيوية بمكتبك، طاقتك الكافية جاهزة ومثبتة أينما كنت.
                </p>
              </div>
              <div className="text-[10px] text-orange-400/80 font-bold bg-orange-500/5 px-2.5 py-1 rounded w-max mt-6 font-mono border border-orange-500/10">
                WORK STATION PROVED
              </div>
            </div>

            {/* In Nature */}
            <div className="bg-slate-950/60 border border-slate-850 hover:border-orange-500/20 rounded-3xl p-5 relative overflow-hidden flex flex-col justify-between group transition-all text-right">
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-orange-500/5 to-transparent rounded-bl-full pointer-events-none" />
              <div>
                <div className="h-44 w-full rounded-2xl overflow-hidden mb-5 border border-slate-900">
                  <img 
                    src="./assets/images/power_bank_camping_1779481238621.png" 
                    alt="باوربانك IRON رفيق التخييم والمغامرات الخارجية" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-white">في الطبيعة والخرجات (Outdoors)</h3>
                  <div className="w-8 h-8 border border-slate-800 rounded-lg flex items-center justify-center text-orange-400 font-bold font-sans text-xs">02</div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed font-sans arabic-leading-relaxed">
                  رفيق رائع وضروري للتخييم في مرتفعات الأطلس والشواطئ المغربية والمواقع الجبلية النائية. شاحن يدعم شحن الكاميرات والتابلت والضوء المحمول لعدة أيام بمصداقية عالية.
                </p>
              </div>
              <div className="text-[10px] text-orange-400/80 font-bold bg-orange-500/5 px-2.5 py-1 rounded w-max mt-6 font-mono border border-orange-500/10">
                OUTDOOR TESTED & READY
              </div>
            </div>

            {/* Commuting */}
            <div className="bg-slate-950/60 border border-slate-850 hover:border-orange-500/20 rounded-3xl p-5 relative overflow-hidden flex flex-col justify-between group transition-all text-right">
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-orange-500/5 to-transparent rounded-bl-full pointer-events-none" />
              <div>
                <div className="h-44 w-full rounded-2xl overflow-hidden mb-5 border border-slate-900">
                  <img 
                    src="./assets/images/power_bank_travel_1779481354085.png" 
                    alt="استخدام البراق والقطارات لشحن الأجهزة أثناء السفر" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-white">في السفر والتنقل (Commuting)</h3>
                  <div className="w-8 h-8 border border-slate-800 rounded-lg flex items-center justify-center text-orange-400 font-bold font-sans text-xs">03</div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed font-sans arabic-leading-relaxed">
                  سواء كنت على متن قطار البراق (Al Boraq) السريع، أو تسافر لعدة ساعات بالسيارة أو الحافلة، شاهد أفلامك المفضلة وتحدث مع عائلتك واستمتع بسفرك بكل ثقة ومزاج رائع.
                </p>
              </div>
              <div className="text-[10px] text-orange-400/80 font-bold bg-orange-500/5 px-2.5 py-1 rounded w-max mt-6 font-mono border border-orange-500/10">
                TRAVEL PROVEN QUALITY
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 7. Conversion Forms & Checkout Sheet Grid */}
      <section className="py-20 relative px-4" id="order">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto w-full">
            
            {/* Checkout Form */}
            <CheckoutForm onOrderSuccess={handleOrderSuccess} />

          </div>
        </div>
      </section>



      {/* 9. FAQ Accordions FAQ */}
      <section className="py-20" id="faq">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FAQSection />
        </div>
      </section>

      {/* 10. Footers aesthetic area */}
      <footer className="bg-[#040507] border-t border-slate-900/85 pt-16 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-slate-900">
            
            {/* Branding widget info */}
            <div className="md:col-span-2 flex flex-col gap-4">
              <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection('hero')}>
                <IronLogo className="h-11 w-auto" />
              </div>
              <p className="text-xs text-slate-400 font-sans leading-relaxed max-w-sm mt-2">
                شركة <strong>IRON</strong> رائدة في صناعة حلول تخزين الطاقة والبطاريات المتكاملة ذات معايير الجودة العالمية المعتمدة لسلامتك وراحة أجهزتك.
              </p>
              <div className="flex items-center gap-3.5 mt-2">
                <a href="#" className="p-2 bg-slate-900 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="#" className="p-2 bg-slate-900 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors">
                  <Facebook className="w-4 h-4" />
                </a>
                <span className="text-xs text-slate-500">حسابات موزع المغرب المعتمد</span>
              </div>
            </div>

            {/* Quick sections Links links */}
            <div className="flex flex-col gap-4 font-semibold text-xs text-slate-400">
              <span className="text-xs font-bold text-white uppercase tracking-wider mb-1">الروابط السريعة</span>
              <button onClick={() => scrollToSection('hero')} className="hover:text-orange-400 transition-colors text-right cursor-pointer">الرئيسية</button>
              <button onClick={() => scrollToSection('simulator-widget')} className="hover:text-orange-400 transition-colors text-right cursor-pointer">مواصفات الشاحن</button>
              <button onClick={() => scrollToSection('order-form')} className="hover:text-orange-400 transition-colors text-right cursor-pointer">نموذج الطلب</button>
            </div>

            {/* Direct Support Contacts info */}
            <div className="flex flex-col gap-4 text-xs text-slate-400">
              <span className="text-xs font-bold text-white uppercase tracking-wider mb-1 font-sans">معلومات الدعم والمبيعات</span>
              <div className="flex flex-col gap-2.5">
                <div className="font-sans leading-relaxed flex flex-col gap-1.5">
                  <p className="font-semibold text-slate-300">نحن هنا لمساعدتك في كل خطوة:</p>
                  <div className="flex flex-col gap-1 text-slate-400 text-[11px] pr-1">
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500/80 shrink-0"></span>
                      <span>استفسارات قبل الشراء</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500/80 shrink-0"></span>
                      <span>تتبع الطلبات والشحن</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500/80 shrink-0"></span>
                      <span>دعم تقني وخدمة ما بعد البيع</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-orange-400 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0"></span>
                      <span>ضمان أصالة المنتج 100%</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 font-mono text-white font-medium mt-1">
                  <Phone className="w-4 h-4 text-orange-500" />
                  <span>0704864461</span>
                </div>
                <span className="text-[10px] text-slate-500">الدعم متوفر طيلة أيام الأسبوع (من 9 صبحاً حتى 8 مساءً)</span>
              </div>
            </div>

          </div>

          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-8 text-[11px] text-slate-500 font-sans">
            <span>حقوق الطبع والنشر © {new Date().getFullYear()} IRON Morocco. جميع الحقوق محفوظة لعلامة آيرون الأصلية.</span>
            <div className="flex gap-4">
              <a href="#" className="hover:underline">سياسة الخصوصية</a>
              <span>•</span>
              <a href="#" className="hover:underline">شروط البيع والتوصيل (الملك الأفضل)</a>
            </div>
          </div>
        </div>
      </footer>

      {/* 11. Interactive order complete modal success screen overlay */}
      <AnimatePresence>
        {showSuccessModal && placedOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 30 }}
              className="bg-slate-900 border-2 border-emerald-500/40 max-w-lg w-full rounded-3xl p-6 md:p-8 text-center relative overflow-hidden text-right"
              dir="rtl"
            >
              {/* Confetti decoration elements styled manually */}
              <div className="absolute top-0 left-0 right-0 h-2.5 bg-gradient-to-r from-emerald-500 to-teal-400" />
              
              <div className="w-16 h-16 bg-emerald-500/15 border border-emerald-500/30 rounded-full flex items-center justify-center text-emerald-400 mx-auto mb-6">
                <FileCheck2 className="w-8 h-8 animate-bounce text-emerald-500" />
              </div>

              <h3 className="text-2xl font-black text-white text-center">لقد تلقينا طلبك بنجاح! 🎉</h3>
              <p className="text-xs text-slate-400 leading-relaxed text-center mt-2">
                شكراً لتسوقكم كابلات وشاحن <strong>IRON</strong> الأصلي. جاري تجهيز علبتك الفاخرة الآن.
              </p>

              {/* Order specifications breakdown receipt */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 my-6 flex flex-col gap-2.5">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span className="font-bold text-slate-200">كود الطلبية للتتبع:</span>
                  <span className="font-mono text-emerald-400 font-extrabold bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
                    {placedOrder.id}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400 border-t border-slate-900 pt-2.5">
                  <span>الزبون:</span>
                  <span className="text-white font-medium">{placedOrder.fullName}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>الهاتف المسجل:</span>
                  <span className="text-white font-medium font-mono">{placedOrder.phoneNumber}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>مدينة التوصيل:</span>
                  <span className="text-white font-medium">{placedOrder.city}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>العنوان المحدد:</span>
                  <span className="text-white font-medium truncate max-w-[200px]">{placedOrder.address}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400 border-t border-slate-900 pt-2.5 font-bold">
                  <span className="text-slate-200">المبلغ المستحق للدفع للموزع:</span>
                  <span className="text-lg font-black text-emerald-400 font-mono">{placedOrder.totalPrice} درهم</span>
                </div>
              </div>

              {/* Steps info for COD */}
              <div className="bg-orange-500/5 border border-orange-500/10 p-4 rounded-xl text-xs text-slate-300 leading-relaxed flex items-start gap-2 mb-6">
                <AlertCircle className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
                <p>
                  <strong>ماذا يحدث بعد ذلك؟</strong> سيتصل بك موزعنا المعتمد خلال الساعات القليلة القادمة لتأكيد العنوان وتحديد ساعة وصول الشاحنة. يرجى الإبقاء على هاتفك مفتوحاً لتسهيل التسليم!
                </p>
              </div>

              {/* Buttons action */}
              <div className="flex justify-center">
                <button
                  onClick={handleCloseModal}
                  className="w-full py-4 bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black text-sm rounded-xl transition-all shadow-md shadow-orange-500/10 hover:opacity-90 cursor-pointer text-center"
                >
                  الرجوع لتصفح الصفحة
                </button>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

// Inline custom utility Icons to bypass external imports safely
function CartIcon({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2.5" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="8" cy="21" r="1" />
      <circle cx="19" cy="21" r="1" />
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
    </svg>
  );
}
