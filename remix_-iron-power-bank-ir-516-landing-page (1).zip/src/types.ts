/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Order {
  id: string;
  fullName: string;
  phoneNumber: string;
  city: string;
  address: string;
  quantity: number;
  shippingFee: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'shipping' | 'delivered';
  createdAt: string;
}

export interface Review {
  id: string;
  name: string;
  city: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  likes: number;
}

export interface PhoneModel {
  name: string;
  batterySize: number; // mAh
  image: string;
}
